using System;
using Xunit;
using YieldCalculator;

namespace BondTest
{
    public class BondTests
    {
        [Fact]
        public void ValidBondIsValidated_Success()
        {
            Bond bond = new Bond("g1","corporate","12.5 years","3.5%",1200);

            Bond validated= Helpercs.ValidateBond(bond);
            Assert.True(validated.IsValid);

        }

        [Fact]
        public void InValidBondYieldNullIsValidated_Fail()
        {
            Bond bond = new Bond("g1", "corporate", "12.5 years", null, 1200);

            Bond validated = Helpercs.ValidateBond(bond);
            Assert.False(validated.IsValid);

        }
    }
}
