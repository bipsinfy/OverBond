Command to Execute 
Move to the BondYield FOlder and run the below command
dotnet YieldCalculator.dll inputFilePathIncludingFileName OutputFIlePathIncludingFileName

 Ex:
dotnet YieldCalculator.dll "C:\Users\puthiyab\Downloads\sde-test\sde-test\sample_input.json" "C:\Users\puthiyab\Downloads\sde-test\sde-test\sample_output2.json"

Unit Tests canbe run 

dotnet test  --logger trx

